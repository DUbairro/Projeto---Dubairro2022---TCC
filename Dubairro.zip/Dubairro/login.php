<?php
require('config/conexao.php');

if(isset($_POST['email']) && isset($_POST['senha']) && !empty($_POST['email']) && !empty($_POST['senha'])){
    //RECEBER OS DADOS VINDO DO POST E LIMPAR
    $email = limparPost($_POST['email']);
    $senha = limparPost($_POST['senha']);
    $senha_cript = sha1($senha);   

    //VERIFICAR SE EXISTE ESTE USUÁRIO
    $sql = $pdo->prepare("SELECT * FROM usuarios WHERE email=? AND senha=? LIMIT 1");
    $sql->execute(array($email,$senha_cript));
    $usuario = $sql->fetch(PDO::FETCH_ASSOC);
    if($usuario){
        //EXISTE O USUARIO
        //VERIFICAR SE O CADASTRO FOI CONFIRMADO
        if($usuario['status']=="confirmado"){
            //CRIAR UM TOKEN
            $token = sha1(uniqid().date('d-m-Y-H-i-s'));

            //ATUALIZAR O TOKEN DESTE USUARIO NO BANCO
            $sql = $pdo->prepare("UPDATE usuarios SET token=? WHERE email=? AND senha=?");
            if($sql->execute(array($token,$email,$senha_cript))){
                //ARMAZENAR ESTE TOKEN NA SESSAO (SESSION)
                $_SESSION['TOKEN'] = $token;
                header('location: perfil.html');
            }
        }else{
            $erro_login = "Por favor confirme o seu e-mail cadastrado!";
        }        

    }else{
        $erro_login = "Usuário e/ou senha incorretos!";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--FONT_AWESOME-->
    <script src="https://kit.fontawesome.com/8588795106.js" crossorigin="anonymous"></script>
    <link rel="shortcut icon" href="./img/logo_alternativa.jpg" type="image/x-icon">

    <!--CSS-->
    <link rel="stylesheet" href="./css/login.css">
    <title>Login | Dubairro</title>
</head>

<body>
    <main>

        <section class="forms_container">
            <div class="title_container">
                <h1>Faça Login<br>ou Cadastre-se<br>no site!</h1>
                <div class="back">
                    <span><i class="fa fa-angle-left"></i></span><a href="./index.html">Voltar</a>
                </div>
            </div>
            <div class="forms_login">
                <div class="forms_content">
                    <h2>Fazer Login</h2>
                    <form method="post" action="#">
                        <div class="input_field">
                            <label for="email">
                                <i class="fa-solid fa-envelope"></i>
                            </label>
                            <input name= "email" type="email" placeholder="E-mail" class="input" required>
                        </div>
                        <div class="input_field">
                            <label for="password">
                                <i class="fa-solid fa-lock"></i>
                            </label>
                            <input name= "senha" id="password" type="password" placeholder="Senha" class="senha" required>
                            <img id="eyesvg" onclick="eyeClick()" src="./img/eye.svg" alt="">
                        </div>

                        <div class="forms_link">
                            <a href="./esqueci.php" class="forgot_pass">Esqueci minha senha</a>
                        </div>

                        <div class="button_field">
                            <button type="submit">Entrar</button>
                        </div>
                        <div class="line"></div>
                        <div class="forms_link">
                            <span>Ainda não tem uma conta?</span><a href="./cadastro_comum.php"
                                class="signup_link">Cadastre-se</a>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </main>

    
    <?php if (isset($_GET['result']) && ($_GET['result']=="ok")){ ?>
        <script>
        setTimeout(function() {
            window.location.href = "https://projetodubairro.000webhostapp.com/login.php";
        }, 3000);</script>
        <div class="success">
        Cadastrado com sucesso!
        </div>  
       <?php }?>

       <?php if(isset($erro_login)){ ?>
            <div class="erro">
            <?php  echo $erro_login; ?>
            </div>
        <?php } ?>


    <!--JavaScript-->
    <script>


        //OCULTAR_SENHA 
    

        const passwordInput = document.getElementById('password')
        const eyesvg = document.getElementById('eyesvg')

        function eyeClick() {
            let inputTypeIsPassword = passwordInput.type == 'password'

            if (inputTypeIsPassword) {
                showPassword()
                //ação
            } else {
                hidePassword()
                //ação
            }
        }

        function showPassword() {

            passwordInput.setAttribute('type', 'text')
        }

        function hidePassword() {

            passwordInput.setAttribute('type', 'password')

        }

    </script>
</body>

</html>
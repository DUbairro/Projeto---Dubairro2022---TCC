<?php
require('config/conexao.php');

if(isset($_GET['cod']) && !empty($_GET['cod'])){
    //LIMPAR O GET
    $cod = limparPost($_GET['cod']);

    //VERIFICAR SE A POSTAGEM EXISTE DE ACORDO COM OS CAMPOS
if(isset($_POST['senha']) && isset($_POST['repete_senha'])){
    //VERIFICAR SE TODOS OS CAMPOS FORAM PREENCHIDOS
    if(empty($_POST['senha']) or empty($_POST['repete_senha'])){
        $erro_geral = "Todos os campos são obrigatórios!";
    }else{
        //RECEBER VALORES VINDOS DO POST E LIMPAR        
        $senha = limparPost($_POST['senha']);
        $senha_cript = sha1($senha);
        $repete_senha = limparPost($_POST['repete_senha']);
      
        //VERIFICAR SE SENHA TEM MAIS DE 6 DÍGITOS
        if(strlen($senha) < 6 ){
            $erro_senha = "Senha deve ter 6 caracteres ou mais!";
        }

        //VERIFICAR SE RETEPE SENHA É IGUAL A SENHA
        if($senha !== $repete_senha){
            $erro_repete_senha = "Senha e repetição de senha diferentes!";
        }
      
        if(!isset($erro_geral)  && !isset($erro_senha) && !isset($erro_repete_senha)){
            //VERIFICAR SE ESTE RECUPERACAO DE SENHA EXISTE
            $sql = $pdo->prepare("SELECT * FROM usuarios WHERE recupera_senha=? LIMIT 1");
            $sql->execute(array($cod));
            $usuario = $sql->fetch();
            //SE NÃO EXISTIR O USUARIO - ADICIONAR NO BANCO
            if(!$usuario){
                echo "Recuperação de senha inválida!";
            }else{
                //JÁ EXISTE USUARIO COM ESSE CÓDIGO DE RECUPERAÇÃO
                 //ATUALIZAR O TOKEN DESTE USUARIO NO BANCO
                $sql = $pdo->prepare("UPDATE usuarios SET senha=? WHERE recupera_senha=?");
                if($sql->execute(array($senha_cript,$cod))){
                    //REDIRECIONAR PARA LOGIN
                    header('location: login.php');
                }
               
            }
        }

    }



}

}else{
    header('location:login.php');
}



?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--FONT_AWESOME-->
    <script src="https://kit.fontawesome.com/8588795106.js" crossorigin="anonymous"></script>
    <link rel="shortcut icon" href="./img/Casa.svg" type="image/x-icon">

    <!--CSS-->
    <link rel="stylesheet" href="./css/alterar.css">
    <title>Altere sua senha</title>
</head>

<body>
    <main>

        <section class="forms_container">
            <div class="forms_login">
                <div class="forms_content">
                    <h2>Alterar senha</h2>
                    <form action="#">
                        <div class="input_field">
                            <label for="password">
                                <i class="fa-solid fa-lock"></i>
                            </label>
                            <input name="senha" type="password" placeholder="Nova senha" class="senha" required>
                        </div>

                        <div class="input_field">
                            <label for="password">
                                <i class="fa-solid fa-lock"></i>
                            </label>
                            <input name="repete_senha" id="password" type="password" placeholder="Senha" class="senha" required>
                            <img id="eyesvg" onclick="eyeClick()" src="./img/eye.svg" alt="">
                        </div>

                        <div class="button_field">
                            <button type="submit">Alterar</button>
                        </div>
                        <div class="back">
                            <span><i class="fa fa-angle-left"></i></span><a href="./recuperar.html">Voltar</a>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </main>

    <!--JavaScript-->
    <script>
        //OCULTAR_SENHA 

        const passwordInput = document.getElementById('password')
        const eyesvg = document.getElementById('eyesvg')

        function eyeClick() {
            let inputTypeIsPassword = passwordInput.type == 'password'

            if (inputTypeIsPassword) {
                showPassword()
                //ação
            } else {
                hidePassword()
                //ação
            }
        }

        function showPassword() {

            passwordInput.setAttribute('type', 'text')
        }

        function hidePassword() {

            passwordInput.setAttribute('type', 'password')

        }

    </script>
</body>

</html>
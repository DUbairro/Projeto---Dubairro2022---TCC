<?php 
  session_start();
  if(isset($_SESSION['unique_id'])){
    header("location: users.php");
  }
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--FONT_AWESOME-->
    <script src="https://kit.fontawesome.com/8588795106.js" crossorigin="anonymous"></script>
    <link rel="shortcut icon" href="./img/Casa.svg" type="image/x-icon">

    <!--CSS-->
    <link rel="stylesheet" href="style.css">
    <title>Cadastro | Dubairro</title>
</head>


<body>
  <div class="wrapper">
    <section class="form signup">
      <header>Cadastro</header>
      <form action="#" method="POST" enctype="multipart/form-data" autocomplete="off">
        <div class="error-text"></div>
        <div class="name-details">
          <div class="field input">
            <input type="text" name="lname" placeholder="Nome" autocomplete="off" required/>
          </div>
        </div>
        <div class="field input">
          <input type="text" name="email" placeholder="E-mail" autocomplete="off" required/>
        </div>
        <div class="field input">
          <input type="password" name="password" id="senha" placeholder="Digite sua senha" autocomplete="off" required/>
          <i class="fas fa-eye"></i>
        </div>
        <div class="field input">
          <input type="password" name="repete_senha" id="repete_senha" class="repete_senha" placeholder="Repita sua senha" autocomplete="off" required/>
          <i class="fas fa-eye" id="eye" aria-hidden="true"></i>
        </div>
        <div class="field image">
          <label id="perfil">Foto de Perfil</label>
          <label for="image" id="file">Enviar arquivo</label>
          <input type="file" name="image" id="image" accept="image/x-png,image/gif,image/jpeg,image/jpg" required>
        </div>
        <div class="field button">
          <input type="submit" name="submit" value="Cadastrar">
        </div>
      </form>
      <div class="link">Já possui uma conta? <a href="login.php">Faça login</a></div>
    </section>
  </div>

  <script src="javascript/pass-show-hide.js"></script>
  <script src="javascript/pass.js"></script>
  <script src="javascript/signup.js"></script>

</body>
</html>

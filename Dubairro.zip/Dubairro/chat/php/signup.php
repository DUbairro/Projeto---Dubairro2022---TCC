<?php
    session_start();
    include_once "config.php";
    $lname = mysqli_real_escape_string($conn, $_POST['lname']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $repete_senha = limparPost($_POST['repete_senha']);

    if(!empty($lname) && !empty($email) && !empty($password) && !empty($repete_senha)){
        if(strlen($password) < 6 ){
            echo "Sua senha deve ter 6 caracteres ou mais!  ";
        }
        //VERIFICAR SE RETEPE SENHA É IGUAL A SENHA
        if($password !== $repete_senha){
            echo "Senha e repetição de senha diferentes!  ";
        }

        if(filter_var($email, FILTER_VALIDATE_EMAIL)){
            $sql = mysqli_query($conn, "SELECT * FROM users WHERE email = '{$email}'");
            if(mysqli_num_rows($sql) > 0){
                echo "$email - Este E-mail já existe!";
            }else{
                if(isset($_FILES['image'])){
                    $img_name = $_FILES['image']['name'];
                    $img_type = $_FILES['image']['type'];
                    $tmp_name = $_FILES['image']['tmp_name'];
                    
                    $img_explode = explode('.',$img_name);
                    $img_ext = end($img_explode);
    
                    $extensions = ["jpeg", "png", "jpg"];
                    if(in_array($img_ext, $extensions) === true){
                        $types = ["image/jpeg", "image/jpg", "image/png"];
                        if(in_array($img_type, $types) === true){
                            $time = time();
                            $new_img_name = $time.$img_name;
                            if(move_uploaded_file($tmp_name,"images/".$new_img_name)){
                                $recupera_senha="";
                                $token="";
                                $codigo_confirmacao = uniqid();
                                $estatus = "novo";
                                $data_cadastro = date('d/m/Y');
                                $ran_id = rand(time(), 100000000);
                                $status = "Active now";
                                $encrypt_pass = md5($password);
                                $insert_query = mysqli_query($conn, "INSERT INTO users (unique_id, lname, email, password, img, status, recupera_senha, token, codigo_confirmacao, estatus, data_cadastro)
                                VALUES ({$ran_id},'{$lname}', '{$email}', '{$encrypt_pass}', '{$new_img_name}', '{$status}', '{$recupera_senha}', '{$token}', '{$codigo_confirmacao}', '{$estatus}', '{$data_cadastro}')");
                                if($insert_query){
                                    $select_sql2 = mysqli_query($conn, "SELECT * FROM users WHERE email = '{$email}'");
                                    if(mysqli_num_rows($select_sql2) > 0){
                                        $result = mysqli_fetch_assoc($select_sql2);
                                        $_SESSION['unique_id'] = $result['unique_id'];
                                        echo "success";
                                    }else{
                                        echo "Este endereço de E-mail não existe!  ";
                                    }
                                }else{
                                    echo "Algo deu errado. Por favor, tente novamente!  ";
                                }
                            }
                        }else{
                            echo "Por favor! Envie uma imagem do tipo - jpeg, png, jpg  ";
                        }
                    }else{
                        echo "Por favor! Selecione um arquivo: jpeg, png ou jpg  ";
                    }
                }
            }
        }else{
            echo "$email não é um E-mail valido!  ";
        }
    }else{
        echo "Preencha todos os Campos!  ";
    }
?>
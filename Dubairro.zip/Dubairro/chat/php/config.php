<?php
  $site = "https://projetodubairro.000webhostapp.com/";

  $modo = 'local'; 

  //CREDENCIAIS LOCAL (XAMPP)
  if($modo =='local'){
      $$hostname = "localhost";
      $username = "root";
      $password = "";
      $dbname = "chat";
    
      $conn = mysqli_connect($hostname, $username, $password, $dbname);
      if(!$conn){
        echo "Database connection error".mysqli_connect_error();
      }
  }
  
  //CREDENCIAIS PRODUÇÃO
  if($modo == 'producao'){
      $hostname ="localhost";
      $username = "id19422015_login";
      $password = "Z4ASv3HBE=M@(buu";
      $dbname = "id19422015_dubairro";
      
      $conn = mysqli_connect($hostname, $username, $password, $dbname);
      if(!$conn){
        echo "Database connection error".mysqli_connect_error();
      }
  }

try{
  $pdo = new PDO("mysql:host=$hostname;dbname=$dbname",$username,$password); 
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
  //echo "Banco conectado com sucesso!"; 
}catch(PDOException $erro){
   echo "Falha ao se conectar com o banco! ";
}

//FUNÇÃO PARA LIMPAR O POST
function limparPost($dados){
   $dados = trim($dados);
   $dados = stripslashes($dados);
   $dados = htmlspecialchars($dados);
   return $dados;
}

//FUNÇÃO PARA AUTENTICAÇÃO
function auth($tokenSessao){
   global $pdo;
   //VERIFICAR SE TEM AUTORIZAÇÃO
   $sql = $pdo->prepare("SELECT * FROM users WHERE token=? LIMIT 1");
   $sql->execute(array($tokenSessao));
   $usuario = $sql->fetch(PDO::FETCH_ASSOC);
   //SE NÃO ENCONTRAR O USUÁRIO
   if(!$usuario){
       return false;
   }else{
      return $usuario;
   }
}
?>

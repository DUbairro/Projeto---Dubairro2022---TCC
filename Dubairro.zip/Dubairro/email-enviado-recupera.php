<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="./img/logo_alternativa.jpg" type="image/x-icon">
    <link href="css/estilo.css" rel="stylesheet">
    <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
  />
    <title>Obrigado por cadastrar!</title>
</head>
<body>
    <div class="text-center">
        <center>
        <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
        <lottie-player src="https://assets8.lottiefiles.com/packages/lf20_4tvpr5xz.json"  background="transparent"  speed="1"  style="width: 300px; height: 300px; text-align:center"  loop  autoplay></lottie-player>
        </center>
        <h1 class="text-center">Recuperação enviado no e-mail!</h1>
        <p class="text-center">Enviamos um e-mail para o endereço informado para você poder trocar a sua senha. Por favor, verifique também na caixa de spams!</p>
        <br><br><a class="gmail" href="http://gg.gg/122lmi">Ir para o Gmail</a>
        <a class="outlook" href="http://gg.gg/122llv">Ir para o Outlook</a>
        <br><br><br>
    </div>
</body>
</html>
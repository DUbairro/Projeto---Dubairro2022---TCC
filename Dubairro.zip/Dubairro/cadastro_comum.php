<?php
require('config/conexao.php');

//REQUERIMENTO DO PHPMAILER
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require 'config/PHPMailer/src/Exception.php';
require 'config/PHPMailer/src/PHPMailer.php';
require 'config/PHPMailer/src/SMTP.php';


 
//VERIFICAR SE A POSTAGEM EXISTE DE ACORDO COM OS CAMPOS
if(isset($_POST['nome_completo']) && isset($_POST['email']) && isset($_POST['senha']) && isset($_POST['repete_senha'])){
    //VERIFICAR SE TODOS OS CAMPOS FORAM PREENCHIDOS
    if(empty($_POST['nome_completo']) or empty($_POST['email']) or empty($_POST['senha']) or empty($_POST['repete_senha']) ){
        
    //Campos Obrigatórios pelo required, definido no POST
    
    }else{
        //RECEBER VALORES VINDOS DO POST E LIMPAR
        $nome = limparPost($_POST['nome_completo']);
        $email =limparPost($_POST['email']);
        $senha = limparPost($_POST['senha']);
        $senha_cript = sha1($senha);
        $repete_senha = limparPost($_POST['repete_senha']);

        //VERIFICAR SE NOME É APENAS LETRAS E ESPAÇOS
        if (!preg_match("/^[a-zA-Z-' ]*$/",$nome)) {
            $erro_nome = "Nome Inválido!Apenas letras e espaços em Branco!";
        }

        //VERIFICAR SE EMAIL É VÁLIDO
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $erro_email = "Formato de e-mail inválido!";
        }

        //VERIFICAR SE SENHA TEM MAIS DE 6 DÍGITOS
        if(strlen($senha) < 6 ){
            $erro_senha = "Senha deve ter 6 caracteres ou mais!";
        }

        //VERIFICAR SE RETEPE SENHA É IGUAL A SENHA
        if($senha !== $repete_senha){
            $erro_repete_senha = "Senha e repetição de senha diferentes!";
        }


        if(!isset($erro_geral) && !isset($erro_nome) && !isset($erro_email) && !isset($erro_senha) && !isset($erro_repete_senha)){
            //VERIFICAR SE ESTE EMAIL JÁ ESTÁ CADASTRADO NO BANCO
            $sql = $pdo->prepare("SELECT * FROM usuarios WHERE email=? LIMIT 1");
            $sql->execute(array($email));
            $usuario = $sql->fetch();
            //SE NÃO EXISTIR O USUARIO - ADICIONAR NO BANCO
            if(!$usuario){
                $recupera_senha="";
                $token="";
                $codigo_confirmacao = uniqid();
                $status = "novo";
                $data_cadastro = date('d/m/Y');
                $sql = $pdo->prepare("INSERT INTO usuarios VALUES (null,?,?,?,?,?,?,?,?)");
                if($sql->execute(array($nome,$email,$senha_cript,$recupera_senha,$token,$codigo_confirmacao,$status, $data_cadastro))){
                    
                    //SE O MODO FOR LOCAL    
                    if($modo =="local"){
                        header('location: login.php?result=ok');
                    }

                    //SE O MODO FOR PRODUCAO
                    if($modo =="producao"){
                        
                        //ENVIAR EMAIL PARA USUARIO
                        $mail = new PHPMailer(true);

                        try {
                        
                         //Server settings
                        //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
                        $mail->isSMTP();                                            //Send using SMTP
                        $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
                        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
                        $mail->Username   = 'dubairro22projeto@gmail.com';                     //SMTP username
                        $mail->Password   = 'dqdlylokxmwbayuv';                               //SMTP password
                        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
                        $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
                    
                        //Recipients
                        $mail->setFrom('dubairro22projeto@gmail.com', 'DUBAIRRO');
                        $mail->addAddress($email,$nome);     //Add a recipient//Name is optional
                        $mail->addReplyTo('dubairro22projeto@gmail.com', 'DUBAIRRO');
                        
                        $mail->isHTML(true);  //CORPO DO EMAIL COMO HTML
                        $mail->Subject = 'Confirme seu cadastro!'; //TITULO DO EMAIL
                        $mail->Body    = '<div style="background-color:#190E2C; text-align: center; justify-content: center;"><h1 style="font-size:20px; color: #fff;">Por favor confirme seu e-mail abaixo:</h1><br><a style="background: #F82056; color: #fff; text-decoration:none; padding:15px 30px; border-radius:5px;" href="'.$site.'confirmacao.php?cod_confirm='.$codigo_confirmacao.'">Confirmar E-mail</a></div>';
                         
                         $mail->send();
                         header('location: obrigado.php');
                       


                       } catch (Exception $e) {
                           echo "Houve um problema ao enviar -email de confirmação: {$mail->ErrorInfo}";
                       }
                       
                    }
                   
                }
            }else{
                //JÁ EXISTE USUARIO APRESENTAR ERRO
                $erro_geral = "Usuário já cadastrado";
            }
                
            
        }

    }



}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--FONT_AWESOME-->
    <script src="https://kit.fontawesome.com/8588795106.js" crossorigin="anonymous"></script>
    <link rel="shortcut icon" href="./img/logo_alternativa.jpg" type="image/x-icon">

    <!--CSS-->
    <link rel="stylesheet" href="./css/cadastro_comum.css">
    <title>Cadastro de Usuário | Dubairro</title>
</head>

<body>
    <main>

        <section class="forms_container">
            <div class="title_container">
                <div class="trocar">
                    <a href="./cadastro_comum.php">Cliente</a>
                    <a href="./cadastro_comercio.php">Comércio</a>
                </div>
                <h1>Junte-se a nós<br>e interaja com<br> o Dubairro!</h1>
                <div class="back">
                    <span><i class="fa fa-angle-left"></i></span><a href="./login.html">Voltar para Login</a>
                </div>
            </div>
            <div class="forms_login">
                <div class="forms_content">
                    <h2>Criar conta</h2>
                    <form method="post" action="#">
                        <div class="input_field">
                            <label for="text">
                                <i class="fa-solid fa-user-large"></i>
                            </label>
                            <input name="nome_completo" type="text" placeholder="Nome completo" class="input">
                        </div>

                        <div class="input_field">
                            <label for="email">
                                <i class="fa-solid fa-envelope"></i>
                            </label>
                            <input name="email" type="email" placeholder="E-mail" class="email">
                        </div>

                        <div class="input_field">
                            <label for="password">
                                <i class="fa-solid fa-lock"></i>
                            </label>
                            <input name="senha" id="password" type="password" placeholder="Senha" class="senha">
                            <img id="eyesvg" onclick="eyeClick()" src="./img/eye.svg" alt="">
                        </div>

                        <div class="input_field">
                            <label for="password">
                                <i class="fa-solid fa-lock"></i>
                            </label>
                            <input name="repete_senha" type="password" placeholder="Confirmar senha" class="senha">
                        </div>

                        <div class="button_field">
                            <button type="submit">Cadastrar</button>
                        </div>
                        <div class="line"></div>
                        <div class="forms_link">
                            <span>Ao se registrar, você aceita nossos</span><a href="#" class="signup_link">termos de
                                uso</a><span> e a nossa</span><a href="#" class="signup_link">política de
                                privacidade</a><span>.</span>
                        </div>
                    </form>
                </div>
            </div>

                            <?php if(isset($erro_geral)){ ?>
                            <div class="erro">
                            <?php  echo $erro_geral; ?>
                            </div>
                            <?php } ?>
        

                            <?php if(isset($erro_nome)){ ?>
                            <div class="erro"><?php echo $erro_nome; ?></div>
                            <?php } ?>
                            
                            <?php if(isset($erro_email)){ ?>
                            <div class="erro"><?php echo $erro_email; ?></div>
                            <?php } ?>

                            <?php if(isset($erro_senha)){ ?>
                            <div class="erro"><?php echo $erro_senha; ?></div>
                            <?php } ?>

                            <?php if(isset($erro_repete_senha)){ ?>
                            <div class="erro"><?php echo $erro_repete_senha; ?></div>
                            <?php } ?> 
        </section>
    </main>

    <!--JavaScript-->
    <script>
        //OCULTAR_SENHA 

        const passwordInput = document.getElementById('password')
        const eyesvg = document.getElementById('eyesvg')

        function eyeClick() {
            let inputTypeIsPassword = passwordInput.type == 'password'

            if (inputTypeIsPassword) {
                showPassword()
                //ação
            } else {
                hidePassword()
                //ação
            }
        }

        function showPassword() {

            passwordInput.setAttribute('type', 'text')
        }

        function hidePassword() {

            passwordInput.setAttribute('type', 'password')

        }

    </script>
</body>

</html>
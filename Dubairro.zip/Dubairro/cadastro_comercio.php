<?php
require('config/conexao.php');

//REQUERIMENTO DO PHPMAILER
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require 'config/PHPMailer/src/Exception.php';
require 'config/PHPMailer/src/PHPMailer.php';
require 'config/PHPMailer/src/SMTP.php';


 
//VERIFICAR SE A POSTAGEM EXISTE DE ACORDO COM OS CAMPOS
if(isset($_POST['nome_comerciante']) && isset($_POST['cnpj']) && isset($_POST['email_comerciante'])){
    //VERIFICAR SE TODOS OS CAMPOS FORAM PREENCHIDOS
    if(empty($_POST['nome_comerciante']) or empty($_POST['cnpj']) && empty($_POST['email_comerciante'])){
        
    //Campos Obrigatórios pelo required, definido no POST
    
    }else{
        //RECEBER VALORES VINDOS DO POST E LIMPAR
        $nome_comerciante = limparPost($_POST['nome_comerciante']);
        $email_comerciante =limparPost($_POST['email_comerciante']);
        $cnpj = limparPost($_POST['cnpj']);
        
        
        //VERIFICAR SE NOME É APENAS LETRAS E ESPAÇOS
        if (!preg_match("/^[a-zA-Z-' ]*$/",$nome_comerciante)) {
            $erro_nome = "Apenas letras e espaços em Branco!";
        }

        //VERIFICAR SE EMAIL É VÁLIDO
        if (!filter_var($email_comerciante, FILTER_VALIDATE_EMAIL)) {
            $erro_email = "Formato de e-mail inválido!";
        }
       
        function validar_cnpj($cnpj)
        {
        	$cnpj = preg_replace('/[^0-9]/', '', (string) $cnpj);
        	
        	// Valida tamanho
        	if (strlen($cnpj) != 14)
        		return false;
        
        	// Verifica se todos os digitos são iguais
        	if (preg_match('/(\d)\1{13}/', $cnpj))
        		return false;	
        
        	// Valida primeiro dígito verificador
        	for ($i = 0, $j = 5, $soma = 0; $i < 12; $i++)
        	{
        		$soma += $cnpj[$i] * $j;
        		$j = ($j == 2) ? 9 : $j - 1;
        	}
        
        	$resto = $soma % 11;
        
        	if ($cnpj[12] != ($resto < 2 ? 0 : 11 - $resto))
        		return false;
        
        	// Valida segundo dígito verificador
        	for ($i = 0, $j = 6, $soma = 0; $i < 13; $i++)
        	{
        		$soma += $cnpj[$i] * $j;
        		$j = ($j == 2) ? 9 : $j - 1;
        	}
        
        	$resto = $soma % 11;
        
        	return $cnpj[13] == ($resto < 2 ? 0 : 11 - $resto);
        }
        if(validar_cnpj($cnpj) == FALSE){
            $erro_cnpj="CNPJ INVÁLIDO";
        }

    }

    
    

        if(!isset($erro_geral) && !isset($erro_comerciante) && !isset($erro_cnpj) && !isset($erro_email)){
            //VERIFICAR SE ESTE EMAIL JÁ ESTÁ CADASTRADO NO BANCO
            $sql = $pdo->prepare("SELECT * FROM comerciantes WHERE email=? LIMIT 1");
            $sql->execute(array($email_comerciante));
            $usuario = $sql->fetch();
            //SE NÃO EXISTIR O USUARIO - ADICIONAR NO BANCO
            if(!$usuario){
                $recupera_senha="";
                $token="";
                $codigo_confirmacao = uniqid();
                $status = "novo";
                $data_cadastro = date('d/m/Y');
                $sql = $pdo->prepare("INSERT INTO comerciantes VALUES (null,?,?,?,?,?,?,?)");
                if($sql->execute(array($nome_comerciante,$cnpj,$email_comerciante,$token,$codigo_confirmacao,$status,$data_cadastro))){
                    
                    //SE O MODO FOR LOCAL    
                    if($modo =="local"){
                        header('location: login.php?result=ok');
                    }

                    //SE O MODO FOR PRODUCAO
                    if($modo =="producao"){
                        
                        //ENVIAR EMAIL PARA USUARIO
                        $mail = new PHPMailer(true);

                        try {
                        
                         //Server settings
                        //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
                        $mail->isSMTP();                                            //Send using SMTP
                        $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
                        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
                        $mail->Username   = 'dubairro22projeto@gmail.com';                     //SMTP username
                        $mail->Password   = 'dqdlylokxmwbayuv';                               //SMTP password
                        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
                        $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
                    
                        //Recipients
                        $mail->setFrom('dubairro22projeto@gmail.com', 'DUBAIRRO');
                        $mail->addAddress($email_comerciante,$nome_comerciante);     //Add a recipient//Name is optional
                        $mail->addReplyTo('dubairro22projeto@gmail.com', 'DUBAIRRO');
                        
                        $mail->isHTML(true);  //CORPO DO EMAIL COMO HTML
                        $mail->Subject = 'Confirme seu cadastro!'; //TITULO DO EMAIL
                        $mail->Body    = '<h1>Por favor confirme seu e-mail abaixo:</h1><br><br><a style="background:green; color:white; text-decoration:none; padding:20px; border-radius:5px;" href="'.$site.'confirmacao.php?cod_confirm='.$codigo_confirmacao.'">Confirmar E-mail</a>';
                         
                         $mail->send();
                         header('location: obrigado.php');
                       


                       } catch (Exception $e) {
                           echo "Houve um problema ao enviar -email de confirmação: {$mail->ErrorInfo}";
                       }
                       
                    }
                   
                }
            }else{
                //JÁ EXISTE USUARIO APRESENTAR ERRO
                $erro_geral = "Usuário já cadastrado";
            }
                
        }}
        


?>


<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--jS-->
    <script src="js/jquery-3.6.1.min.js" type="text/javascript"></script>
    <script src="js/jquery.mask.min.js" type="text/javascript"></script>

    <script type="text/javascript">
    $(document).ready(function(){
    $("#cnpj").mask("00.000.000/0000-00");
    }) 
    </script>
    <!--FONT_AWESOME-->
    <script src="https://kit.fontawesome.com/8588795106.js" crossorigin="anonymous"></script>
    <link rel="shortcut icon" href="./img/logo_alternativa.jpg" type="image/x-icon">
    <!--CSS-->
    <link rel="stylesheet" href="./css/cadastro_comercio.css">
    <title>Cadastro de Comércio | Dubairro</title>
</head>

<body>
    <main>

        <section class="forms_container">
            <div class="title_container">
                <div class="trocar">
                    <a href="./cadastro_comum.php">Cliente</a>
                    <a href="./cadastro_comercio.php">Comércio</a>
                </div>
                <h1>Junte-se a nós<br>e interaja com<br> o Dubairro!</h1>
                <div class="back">
                    <span><i class="fa fa-angle-left"></i></span><a href="./login.php">Voltar para Login</a>
                </div>
            </div>
            <div class="forms_login">
                <div class="forms_content">
                    <h2>Cadastrar comércio</h2>
                    <form method="post" action="#">
                        <div class="input_field">
                            <label for="text">
                                <i class="fa-solid fa-house"></i>
                            </label>
                            <input name="nome_comerciante" type="text" placeholder="Nome do Comércio" class="input" required>
                        </div>

                        <div class="input_field">
                            <label for="number">
                                <i class="fa-solid fa-paste"></i>
                            </label>
                            <input name="cnpj" id="cnpj" type="text" placeholder="CNPJ" class="input" required>
                        </div>

                        <div class="input_field">
                            <label for="email">
                                <i class="fa-solid fa-envelope"></i>
                            </label>
                            <input name="email_comerciante" type="email" placeholder="E-mail" class="input" required>
                        </div>

                        <div class="button_field">
                            <button type="submit">Cadastrar</button>
                        </div>
                        <div class="line"></div>
                        <div class="forms_link">
                            <span>Ao se registrar, você aceita nossos</span><a href="#" class="signup_link">termos de
                                uso</a><span> e a nossa</span><a href="#" class="signup_link">política de
                                privacidade</a><span>.</span>
                        </div>
                    </form>
                </div>
            </div>

                            <?php if(isset($erro_geral)){ ?>
                            <div class="erro">
                            <?php  echo $erro_geral; ?>
                            </div>
                            <?php } ?>
        

                            <?php if(isset($erro_nome)){ ?>
                            <div class="erro"><?php echo $erro_nome; ?></div>
                            <?php } ?>
                            
                            <?php if(isset($erro_email)){ ?>
                            <div class="erro"><?php echo $erro_email; ?></div>
                            <?php } ?>

                            <?php if(isset($erro_cnpj)){ ?>
                            <div class="erro"><?php echo $erro_cnpj; ?></div>
                            <?php } ?>



        </section>
    </main>


</body>

</html>